let db;

// Open IndexedDB
const request = indexedDB.open("AgricultureDB", 1);

request.onupgradeneeded = function(event) {
  db = event.target.result;
  const store = db.createObjectStore("FarmData", { keyPath: "id", autoIncrement: true });
  store.createIndex("sensorReadings", "sensorReadings", { unique: false });
  store.createIndex("note", "note", { unique: false });
  store.createIndex("gps", "gps", { unique: false });
  store.createIndex("timestamp", "timestamp", { unique: false });
  store.createIndex("image", "image", { unique: false });
  log("Object store created");
};

request.onsuccess = function(event) {
  db = event.target.result;
  log("Database opened successfully");
};

request.onerror = function() {
  log("Error opening DB");
};

// Utility logger
function log(msg) {
  document.getElementById("log").innerText += msg + "\n";
  console.log(msg);
}

// Add record from form
document.getElementById("dataForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const sensor = document.getElementById("sensor").value.split(",").map(Number);
  const note = document.getElementById("note").value;
  const gps = document.getElementById("gps").value;
  const file = document.getElementById("image").files[0];
  const timestamp = new Date().toISOString();

  const reader = new FileReader();
  reader.onload = function() {
    const imageData = reader.result;

    const tx = db.transaction("FarmData", "readwrite");
    const store = tx.objectStore("FarmData");
    store.add({ sensorReadings: sensor, note, gps, timestamp, image: imageData });

    tx.oncomplete = () => {
      log("Record added");
      document.getElementById("dataForm").reset();
    };
  };
  reader.readAsDataURL(file);
});

// Display data
function displayData() {
  const tbody = document.querySelector("#dataTable tbody");
  tbody.innerHTML = "";

  const tx = db.transaction("FarmData", "readonly");
  const store = tx.objectStore("FarmData");

  store.openCursor().onsuccess = function(event) {
    const cursor = event.target.result;
    if (cursor) {
      const { id, sensorReadings, note, gps, timestamp, image } = cursor.value;

      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${id}</td>
        <td>${sensorReadings.join(", ")}</td>
        <td>${note}</td>
        <td>${gps}</td>
        <td>${timestamp}</td>
        <td><img src="${image}" alt="crop"></td>
      `;
      tbody.appendChild(row);
      cursor.continue();
    }
  };
}

// Reset DB
function resetDB() {
  const tx = db.transaction("FarmData", "readwrite");
  tx.objectStore("FarmData").clear();
  tx.oncomplete = () => {
    log("Database cleared");
    displayData();
  };
}

// Bulk Insert 10,000 records
function bulkInsert() {
  const tx = db.transaction("FarmData", "readwrite");
  const store = tx.objectStore("FarmData");

  for (let i = 0; i < 10000; i++) {
    const record = {
      sensorReadings: [Math.random()*100, Math.random()*100, Math.random()*100],
      note: "Auto record " + i,
      gps: `${(Math.random()*180-90).toFixed(5)}, ${(Math.random()*360-180).toFixed(5)}`,
      timestamp: new Date().toISOString(),
      image: "images/Crop1.jpg"
    };
    store.add(record);
  }

  tx.oncomplete = () => log("10,000 records inserted");
}

// ================== TEST CASES ===================
async function runTests() {
  log("Running IndexedDB unit tests…");

  await testAddAndGetRoundTrip();
  await testImageExtension();
  await testSensorReadingsAreNumericArray();
  await testGPSRange();
  await testCountAfterBulkInsert();

  log("All tests finished ✅");
}

function testAddAndGetRoundTrip() {
  return new Promise(resolve => {
    const tx = db.transaction("FarmData", "readwrite");
    const store = tx.objectStore("FarmData");
    const record = { sensorReadings: [1,2,3], note: "test", gps: "0,0", timestamp: new Date().toISOString(), image: "images/Crop1.jpg" };
    const req = store.add(record);

    req.onsuccess = function(e) {
      const id = e.target.result;
      store.get(id).onsuccess = function(ev) {
        if (ev.target.result.note === "test") log("✅ testAddAndGetRoundTrip passed");
        resolve();
      };
    };
  });
}

function testImageExtension() {
  return new Promise(resolve => {
    const tx = db.transaction("FarmData", "readonly");
    const store = tx.objectStore("FarmData");
    store.openCursor().onsuccess = function(e) {
      const cursor = e.target.result;
      if (cursor) {
        const extOk = cursor.value.image.endsWith(".jpg") || cursor.value.image.startsWith("data:image/");
        if (extOk) log("✅ testImageExtension passed");
        resolve();
      }
    };
  });
}

function testSensorReadingsAreNumericArray() {
  return new Promise(resolve => {
    const tx = db.transaction("FarmData", "readonly");
    const store = tx.objectStore("FarmData");
    store.openCursor().onsuccess = function(e) {
      const cursor = e.target.result;
      if (cursor) {
        const arrOk = Array.isArray(cursor.value.sensorReadings) && cursor.value.sensorReadings.every(n => typeof n === "number");
        if (arrOk) log("✅ testSensorReadingsAreNumericArray passed");
        resolve();
      }
    };
  });
}

function testGPSRange() {
  return new Promise(resolve => {
    const tx = db.transaction("FarmData", "readonly");
    const store = tx.objectStore("FarmData");
    store.openCursor().onsuccess = function(e) {
      const cursor = e.target.result;
      if (cursor) {
        const [lat, lon] = cursor.value.gps.split(",").map(Number);
        if (lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) log("✅ testGPSRange passed");
        resolve();
      }
    };
  });
}

function testCountAfterBulkInsert() {
  return new Promise(resolve => {
    const tx = db.transaction("FarmData", "readonly");
    const store = tx.objectStore("FarmData");
    const req = store.count();
    req.onsuccess = function() {
      if (req.result >= 10000) log("✅ testCountAfterBulkInsert passed");
      resolve();
    };
  });
}



// 1. Test round-trip insert + get
function testAddAndGetRoundTrip() {
    return new Promise((resolve, reject) => {
        const tx = db.transaction("FarmData", "readwrite");
        const store = tx.objectStore("FarmData");
        const testRecord = {
            sensorReadings: [10, 20, 30, 40, 50],
            cropPhoto: "images/Crop1.jpg",
            farmerNote: "Test Note",
            gps: { lat: 12.34, lon: 56.78 },
            timestamp: new Date().toISOString()
        };
        const req = store.add(testRecord);

        req.onsuccess = function () {
            const getReq = store.get(req.result);
            getReq.onsuccess = function () {
                if (getReq.result && getReq.result.farmerNote === "Test Note") {
                    resolve();
                } else {
                    reject("Data mismatch");
                }
            };
        };
        req.onerror = () => reject(req.error);
    });
}

// 2. Test image path extension
function testImageExtension() {
    const photo = "images/Crop1.jpg";
    if (!photo.endsWith(".jpg") && !photo.endsWith(".png")) {
        throw new Error("Invalid image format");
    }
}

// 3. Test sensor readings are numbers
function testSensorReadingsAreNumericArray() {
    const readings = [1, 2, 3, 4, 5];
    if (!Array.isArray(readings) || !readings.every(x => typeof x === "number")) {
        throw new Error("Sensor readings are not numeric array");
    }
}

// 4. Test GPS coordinates range
function testGPSRange() {
    const gps = { lat: -7.72, lon: 113.45 };
    if (gps.lat < -90 || gps.lat > 90 || gps.lon < -180 || gps.lon > 180) {
        throw new Error("GPS out of range");
    }
}

// 5. Test record count after bulk insert
function testCountAfterBulkInsert() {
    return new Promise((resolve, reject) => {
        const tx = db.transaction("FarmData", "readonly");
        const store = tx.objectStore("FarmData");
        const countReq = store.count();

        countReq.onsuccess = function () {
            if (countReq.result >= 10000) {
                resolve();
            } else {
                reject("Not enough records inserted");
            }
        };
        countReq.onerror = () => reject(countReq.error);
    });
}



// ==============================
// Simple Test Runner
// ==============================
function runTests() {
    console.log("Running IndexedDB unit tests…");

    try {
        testAddAndGetRoundTrip();
        console.log("✅ testAddAndGetRoundTrip passed");
    } catch (e) {
        console.error("❌ testAddAndGetRoundTrip failed", e);
    }

    try {
        testImageExtension();
        console.log("✅ testImageExtension passed");
    } catch (e) {
        console.error("❌ testImageExtension failed", e);
    }

    try {
        testSensorReadingsAreNumericArray();
        console.log("✅ testSensorReadingsAreNumericArray passed");
    } catch (e) {
        console.error("❌ testSensorReadingsAreNumericArray failed", e);
    }

    try {
        testGPSRange();
        console.log("✅ testGPSRange passed");
    } catch (e) {
        console.error("❌ testGPSRange failed", e);
    }

    try {
        testCountAfterBulkInsert();
        console.log("✅ testCountAfterBulkInsert passed");
    } catch (e) {
        console.error("❌ testCountAfterBulkInsert failed", e);
    }

    console.log("All tests finished ✅");
}


db.onsuccess = function(event) {
    db = event.target.result;
    console.log("Database opened successfully");

    // Run tests after DB is open
    setTimeout(runTests, 2000); 
};
